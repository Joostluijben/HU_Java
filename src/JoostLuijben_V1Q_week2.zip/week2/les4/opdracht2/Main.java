/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week3.les5.opdracht1
 */
package week2.les4.opdracht2;

public class Main {

	public static void main(String[] args) {
		
	//1. 66 en hoger
	//2. alle waardes
	//3. alle waardes
	//4. alles tussen 10 en 20 en alles boven 40
	//5. alle waardes boven 10
	//6. alles tussen 10 en 20
	//7. char is A en char is B (kan niet)
	//8. als char niet A of niet B is
	}

}
