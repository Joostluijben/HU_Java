/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week3.les5.opdracht1
 */
package week2.les4.opdracht1;

public class Main {

	public static void main(String[] args) {
		//1. waarde 23 type int
		//2. waarde 4.0 type double
		//3. waarde 7.5 type double
		//4. waarde 12 type int
		//5. waarde 12 type double
		//6. waarde 3345 type String
		//7. waarde 13 type int
		//8. waarde 4 type int
		//9. waarde 8374 type int
		//10. waarde 62 type int
		//11. waarde 10.5 type double
		//12. waarde 10 type int
		//13. waarde 10.5 type double
		//14. a=6 type int b=6 type int c=6 type int d=6 type int
		//15. m=20 type int a=7 type int b=6 type int c=7 type int
	}

}
