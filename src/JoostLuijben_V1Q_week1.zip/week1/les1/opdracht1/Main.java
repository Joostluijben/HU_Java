/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week3.les5.opdracht1
 */

package week1.les1.opdracht1;

public class Main {
	 public static void main(String[] args) {
	 String naam = "Joost";
	 //naam = "Joost";
	 System.out.println("Hallo " + naam);
	 }
}
