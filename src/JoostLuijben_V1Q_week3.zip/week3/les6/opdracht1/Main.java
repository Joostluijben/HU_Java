/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week3.les6.opdracht1
 */
package week3.les6.opdracht1;

/**
 * 
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 1. Verwachte uitkomst: 
		// s1: "route66"
		// s2: "66route"
		// s1 = "route" + 6 + 6;
		// s2 = 6 + 6 + "route";
		// Uitkomst is error, cannot be resolved to a variable. Omdat het geen string of iets anders is
		
		// 2. nee. == vergelijkt het letterlijk dus met de +. .equals vergelijkt het nadat de contaminatie is uitgevoerd
		
		// 3. bijvoorbeeld s1.length()
		// Dat is inclusief spaties en eventuele leestekens
		
		// 4. Met s4.charAt(3)
		
		// 5. Met bijvoorbeeld 1.compareToString()
		
		// 6. Met Integer.parseInt() of voor double Double.parseDouble()		

	}

}
