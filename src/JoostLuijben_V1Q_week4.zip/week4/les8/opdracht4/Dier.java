package week4.les8.opdracht4;

public interface Dier {
	public int getAantalPoten();
	public void setAantalPoten(int aantalPoten);
}

