package week4.les8.opdracht4;

public interface Huisdier {
	public String getNaam();
	public void setNaam(String naam);
	
	public String spelen(); 

}
