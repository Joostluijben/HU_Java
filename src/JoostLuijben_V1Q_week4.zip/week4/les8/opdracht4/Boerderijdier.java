package week4.les8.opdracht4;

public interface Boerderijdier {
	public String getNaam();
	public void setNaam(String naam);
	
	public int getWekenDrachtig(); 
}

