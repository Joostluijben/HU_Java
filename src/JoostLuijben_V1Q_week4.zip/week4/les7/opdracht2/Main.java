/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week4.les7.opdracht2
 */
package week4.les7.opdracht2;

/**
 * 
 */
public class Main {
	//1. ja
	//2. nee
	//3. ja
	//4. nee
	//5. nee
	//6. ja
	//7. ja
	//8. nee
	//9. ja
	//10. nee
	//11. ja
	//12. nee
	//13. ja
	//14. nee
	//15. ja
	//16. nee
	//17. ja
	//18. ja
	//19. nee
	//20. ja
	//21. nee
}
