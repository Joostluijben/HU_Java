/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week4.les7.practicum1
 */
package week4.les7.practicum1;

import java.time.LocalDate;

/**
 * 
 */
public class Auto extends Voertuig{
	private String kenteken;
	
	public Auto(String tp, double pr, int jr, String kt) {
		super(tp, pr, jr);
		kenteken = kt;
	}
	public double huidigeWaarde() {
		double jaarVerschil = LocalDate.now().getYear() - bouwjaar;
		return Math.round((nieuwPrijs * Math.pow(0.7, jaarVerschil)) * 100d) / 100d;
	}
	
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}
