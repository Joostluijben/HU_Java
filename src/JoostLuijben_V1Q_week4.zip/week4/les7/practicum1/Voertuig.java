/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week4.les7.practicum1
 */
package week4.les7.practicum1;

/**
 * 
 */
public abstract class Voertuig implements Goed{
	private String type;
	protected double nieuwPrijs;
	protected int bouwjaar;
	
	public Voertuig(String tp, double pr, int jr) {
		type = tp;
		nieuwPrijs = pr;
		bouwjaar = jr;
	}
	
	public boolean equals(Object obj) {
		boolean gelijkeObjecten = false;
		
		if (obj instanceof Voertuig) {
			Voertuig andereVoertuig = (Voertuig) obj;
			if (this.type.equals(andereVoertuig.type)) {
				gelijkeObjecten = true;
			}
		}
		
		return gelijkeObjecten;
	}
	
	public String toString() {
		String s ="Voertuig: " + type + " met bouwjaar " + bouwjaar;
		s += " heeft een waarde van: €" + huidigeWaarde();
		return s;
	}
}
