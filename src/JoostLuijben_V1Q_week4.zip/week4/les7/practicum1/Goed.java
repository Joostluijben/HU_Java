package week4.les7.practicum1;

public interface Goed {
	public double huidigeWaarde();
	
}
