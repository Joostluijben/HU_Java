/**
 * @author Joost Luijben
 *
 * @studentnummer 1718331
 * 
 * @opdracht week4.les7.practicum1
 */
package week4.les7.practicum1;

import java.time.LocalDate;

/**
 * 
 */
public class Fiets extends Voertuig{
	private int framenummer;
	
	public Fiets(String tp, double pr, int jr, int fnr) {
		super(tp, pr, jr);
		framenummer = fnr;
	}
	
	public double huidigeWaarde() {
		double jaarVerschil = LocalDate.now().getYear() - bouwjaar;
		return Math.round((nieuwPrijs * Math.pow(0.9, jaarVerschil)) * 100d) / 100d;
	}
	
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}
